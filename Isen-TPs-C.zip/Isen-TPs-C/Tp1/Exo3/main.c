#include <math.h>
#include <stdio.h>
#include <locale.h>

int main()
{
	int NoMarche;
		for (NoMarche = 1; NoMarche <= 100; NoMarche++);
		{
			
		}
}