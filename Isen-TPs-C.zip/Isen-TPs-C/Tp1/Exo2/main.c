#include <stdio.h>
#include <stdlib.h>
	
typedef unsigned char boolean;
typedef unsigned char byte;

int main()
{
	const int A = 1, B = 2, C = 3;
	printf("Voici les valeures des variables : A=%d,B=%d, C=%d\nVoici les adresses des trois variables : A=%X, B=%X, C=%X\n", A, B, C, &A, &B, &C);
	char Oneletter = 'A';
	char Anotherletter = 66;
	byte toto = 0;
	unsigned char VerySmallCounter = 255;
	short SmallCounter = 32767;
	int Counter = 0;
	long LargeCOunter = 2147483647;
	unsigned long FullRangeLargeCounter = 4294967295;
	int ChienDeGarde = 0;
	float Dim1 = 1.414F;
	double Dim2 = .5L;
	boolean TestResult = 1;
	const double Pi = 3.14159265L;
	printf("\n");
	printf("exemple d'affichage d'un caratere %c, codage sur %d octets\n", Oneletter, sizeof(Oneletter));
	printf("exemple d'affichage d'un entier court %d, codage sur %d octets\n", Counter, sizeof(Counter));
	printf("exemple %c, codage %d\n", Anotherletter, sizeof(Anotherletter));
	printf("exemple %u, codage %d\n", VerySmallCounter, sizeof(VerySmallCounter));
	printf("Exemple %d, codage %d\n", SmallCounter, sizeof(SmallCounter));
	printf("exemple %d, codage %d\n", LargeCOunter, sizeof(LargeCOunter));
	printf("exemple %d, codage %d\n", ChienDeGarde, sizeof(ChienDeGarde));
	printf("exemple %f, codage %d\n", Dim1, sizeof(Dim1));
	printf("exemple %f, codage %d\n", Dim2, sizeof(Dim2));
	printf("exemple %d, codage %d\n", TestResult, sizeof(TestResult));
	printf("exemple %f, codage %d\n", Pi, sizeof(Pi));
	printf("exemple %d, codage %d\n", toto, sizeof(toto));
	printf("exemple %u, codage %d\n", FullRangeLargeCounter, sizeof(FullRangeLargeCounter));
	system("pause");
	return(EXIT_SUCCESS);
	/*   Taille en octet; Valeur minimum; Valeur maximum; Natif; D�fini � partir de ?;
	Char:1; 1; 2^7;
	Byte:1;1 ; 2^7;
	unsigned char:1; 1; 2^7;
	short int:2; 1; 2^7;  
	int: 4; 1; 2^31
	long: 4; 1; 2^31; 
	unsigned long:4; 1; 2^31; 
	float: 4; 1; 2^31; 
	double: 8; 1; 2^63; 
	*/
}