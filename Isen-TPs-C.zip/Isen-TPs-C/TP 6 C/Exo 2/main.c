#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

#define NbChiffresMax 30

typedef enum { false, true } bool;
typedef  int GrandEntier[NbChiffresMax];

static unsigned long long Produit = 0;			/*  la valeur du dernier factoriel calcul�. Elle est globale*/
static unsigned long long N = 1;			/*  la variable qui contr�le le d�but de la boucle. Elle est globale*/

int AjouteADroite(GrandEntier Nb, int Chiffre) {//Fct last Exo
	bool perte = false;
	if (Nb[0] != 0)
		perte = true;
	for (int i = 0; i < NbChiffresMax - 1; i++)
		Nb[i] = Nb[i + 1];
	Nb[NbChiffresMax - 1] = Chiffre;


	if (perte)
		return -1;

	else
		return 0;
}
void Initialise(GrandEntier Nombre)//Fct last Exo
{
	for (int i = 0; i < NbChiffresMax; i++)
	{
		Nombre[i] = 0;
	}
}
void Affiche(GrandEntier Nombre)//Fct last Exo
{
	int i = 0;
	while (Nombre[i] == 0 && i < NbChiffresMax - 1)
	{
		i++;
		printf(" ");
		if (i % 3 == 0)
			printf(" ");
	}
	for (i; i < NbChiffresMax; i++)
	{
		printf("%d", Nombre[i]);
		if ((i + 1) % 3 == 0)
			printf(" ");
	}
}

int Multiplication(GrandEntier Nb1, long int factor, GrandEntier Result)//Foncton inspir�e du pr�c�dent exercise pour r�aliser les factoriels correctement
{
	Initialise(Result);
	for (int i = NbChiffresMax - 1; i >= 0; i--)
	{
		if (Result[i] == 0)
			Result[i] = 1;
		Result[i] *= (Nb1[i] * factor);
		if (Result[i] > 9 && i > 0)
		{
			Result[i - 1] = (int)Result[i] / 10;
			Result[i] %= 10;
		}
	}
	return 0;

}

/*LA VALEUR DE N EST FAUSSE A PARTIR DE 66 IL FAUT CHANGER LE TYPE POUR AUGMENTER LA VALEUR MAX */

unsigned long long factorielle(unsigned int n)
{
	unsigned short nbBoucle = 0;
	if (Produit == n)
	{
		printf("nombre de boucle :%d\n", nbBoucle);
		return N;
	}
	else if (Produit < n)
	{
		for (unsigned int i = n; i > Produit; i--)
		{
			N *= i;
			nbBoucle++;
		}
		Produit = n;
		printf("nombre de boucle :%d\n", nbBoucle);
		return N;
	}
	else
	{
		N = 1;
		for (unsigned int i = 1; i <= n; i++)
		{
			N *= i;
			nbBoucle++;
		}
		Produit = n;
		printf("nombre de boucle :%d\n", nbBoucle);
		return N;
	}
}


int main()
{
	long long int n;//n max val = 66
	unsigned long long factor;
	do
	{
		scanf_s("%lld", &n);
		factor = factorielle(n);
		printf("le factoriel de %lld est : %llu \n", n, N);
	} while (factor != 0);
	
	GrandEntier nb1;
	GrandEntier Result;

	Initialise(nb1);
	Initialise(Result);

	AjouteADroite(nb1, 1);
	AjouteADroite(Result, 1);
	for (long int i = 2; i < 12; i++)
	{
		Multiplication(nb1, i, Result);
	}

	Affiche(Result);

	system("pause");
	return 0;
}	