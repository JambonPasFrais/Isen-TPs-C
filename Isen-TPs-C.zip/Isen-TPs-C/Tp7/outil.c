#include <stdio.h>   /* pour les entr�es-sorties */
#include <string.h>  /* pour les manipulations de cha�nes de caract�res */
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include <locale.h>
#include "rep.h"

#define VERSION 2.4
#define SQUELET
/**************************************************************************/
/* Compl�ter votre nom ici                                                */
/*   Nom : DEFFRENNES              Pr�nom : Armand   CIR1 2019-2020       */
/**************************************************************************/

extern bool modif;


/**********************************************************************/
/*  Ajout d'un contact dans le r�pertoire stock� en m�moire           */
/**********************************************************************/

int ajouter_un_contact_dans_rep(Repertoire *rep, Enregistrement enr)
{
#ifdef IMPL_TAB
	// compl�ter code ici pour tableau
	int idx;

	if (rep->nb_elts < MAX_ENREG) //V�rification de la validit� de la requ�te "ajouter un contact" 
	{
		rep->tab[rep->nb_elts] = enr;
		compact(rep->tab[rep->nb_elts].tel);
		rep->nb_elts++;
		modif = true;
		rep->est_trie = false;
		trier(rep);
		return(OK);
	}
	else {
		return(ERROR);
	}

	
#else
#ifdef IMPL_LIST
	// compl�ter code ici pour Liste
	bool inserted = false;
	if (rep->nb_elts == 0) {
		if (InsertElementAt(rep->liste, rep->liste->size, enr) != 0) {
			rep->nb_elts += 1;
			modif = true;
			rep->est_trie = true;
			return(OK);
		}

	}

	else if (rep->nb_elts > 0)
	{
		int cpt = 0; //Initialisation du compteur
		SingleLinkedListElem* Elmt = GetElementAt(rep->liste, cpt); //On prend le compteur de maillon � partir de 0
		Enregistrement* tmp; //Variable temporaire pour manipuler la liste
		tmp = Elmt->pers.nom;
		while (cpt < rep->nb_elts && (est_sup(*tmp, enr) == false)) //Tant que l'ordre est faux et que le compteur ne d�passe pas le nombre d'�l�ments pr�sents dans rep
		{
			cpt++;
			tmp = Elmt->next->pers.nom;
		}//La boucle sert � arriver au dernier pointeur de maillon pour par la suite ajouter le contact sur un nouveau pointeur.
		InsertElementAt(rep->liste, cpt, enr); //Ajoute le contact � la position trouv�e
		rep->est_trie == true;
		rep->nb_elts++;
		modif = true;
		return(OK);
	}
	else {
		return(ERROR);
	}
#endif
	
#endif


	return(OK);

} /* fin ajout */
  /**********************************************************************/
  /* supprime du r�pertoire l'enregistrement dont l'indice est donn� en */
  /*   param�tre       et place modif = true                            */
  /**********************************************************************/
#ifdef IMPL_TAB
void supprimer_un_contact_dans_rep(Repertoire *rep, int indice) {

	// compl�ter code ici pour tableau
	if (rep->nb_elts >= 1)		/* s'il y a au moins un element ds le tableau et que l'indice pointe a l'interieur*/
	{
		for (int i = indice; i < rep->nb_elts; i++) {
			rep->tab[i] = rep->tab[i + 1];
		}
		rep->nb_elts -= 1;// ds ts les cas, il y a un element en moins
		modif = true;
	}

	return;
} /* fin supprimer */

#else
#ifdef IMPL_LIST
  /************************************************************************/
  /* supprime du r�pertoire l'enregistrement contenu dans le maillon elem */
  /*                   et fixe modif � vrai                              */
  /************************************************************************/
  // complet

	int supprimer_un_contact_dans_rep_liste(Repertoire *rep, SingleLinkedListElem *elem) {
	
	int ret=DeleteLinkedListElem(rep->liste, elem);
	if (ret == 1) {
		rep->nb_elts--;
		modif = true;
	}

	return (0); 
	}
#endif
#endif


  /**********************************************************************/
  /*  fonction d'affichage d'un enregistrement sur une ligne � l'�cran  */
  /* ex Dupont, Jean                 0320304050                         */
  /**********************************************************************/
void affichage_enreg(Enregistrement enr)
{
	// code � compl�ter ici
	printf("%s, %s				%s\n", enr.nom, enr.prenom, enr.tel); // Affichage selon l'exemple ci-dessus

} /* fin affichage_enreg */
  /**********************************************************************/
  /*  fonction d'affichage d'un enregistrement avec alignement des mots */
  /* pour les listes                                                    */
  /* ex | Dupont                |Jean                  |0320304050      */
  /**********************************************************************/
void affichage_enreg_frmt(Enregistrement enr)
{
	// code � compl�ter ici
	// comme fonction affichage_enreg, mais avec pr�sentation align�es des infos
	printf("Nom: %-10s Pr�nom: %-20s Tel: %-10s\n", enr.nom, enr.prenom, enr.tel);

} /* fin affichage_enreg */


  /**********************************************************************/
  /* test si dans l'ordre alphabetique, un enregistrement est apres     */
  /* un autre                                                           */
  /**********************************************************************/
bool est_sup(Enregistrement enr1, Enregistrement enr2)
{
	// code � compl�ter ici
	int test = strcmp(enr1.nom, enr2.nom); /* strcmp compare lexicalement les deux cha�nes caract�re par caract�re et renvoie 0 si les deux cha�nes sont �gales*/
	if (test == 0 || test > 0)			   /*un nombre positif si chaine 1 est lexicographiquement sup�rieure � chaine 2*/
		return(false);					   /*et un nombre n�gatif si chaine 1 est lexicographiquement inf�rieure � chaine 2. */
	else
		return(true);
}
 
/*********************************************************************/
/*   Tri Alphabetique du tableau d'enregistrements                   */
/*********************************************************************/

void trier(Repertoire *rep)
{

#ifdef IMPL_TAB
	// ajouter code ici pour tableau
	int pos = 0;
	while ((rep->est_trie == false) && (pos < rep->nb_elts - 1))
	{
		if (est_sup(rep->tab[pos + 1], rep->tab[pos])) {//Si la fonction "est sup�rieure" retourne TRUE, on va permuter les deux valeurs
			Enregistrement tmp = rep->tab[pos];
			rep->tab[pos] = rep->tab[pos + 1];
			rep->tab[pos + 1] = tmp;
			pos = 0;
		}
		pos++;//On avance dans le trie
	}


	
#else
#ifdef IMPL_LIST
	// ajouter code ici pour Liste
	// rien � faire !
	// la liste est toujours tri�e
#endif
#endif


	rep->est_trie = true;

} /* fin trier */

  /**********************************************************************/
  /* recherche dans le r�pertoire d'un enregistrement correspondant au  */
  /*   nom � partir de l'indice ind                                     */
  /*   retourne l'indice de l'enregistrement correspondant au crit�re ou*/
  /*   un entier n�gatif si la recherche est n�gative				    */
  /**********************************************************************/

int rechercher_nom(Repertoire *rep, char nom[], int ind)
{
	int i = ind;		    /* position (indice) de d�but de recherche dans tableau/liste rep */
	int ind_fin;			/* position (indice) de fin de tableau/liste rep */

	char tmp_nom[MAX_NOM];	/* 2 variables temporaires dans lesquelles */
	char tmp_nom2[MAX_NOM];	/* on place la chaine recherchee et la chaine lue dans le */
							/* tableau, afin de les convertir en majuscules et les comparer */
	bool trouve = false;		


#ifdef IMPL_TAB
	// ajouter code ici pour tableau
	strcpy_s(tmp_nom, MAX_NOM, nom);
	toupper(tmp_nom);
	for (int i = 0; i < rep->nb_elts; i++)
	{
		strcpy_s(tmp_nom2, MAX_NOM, rep->tab[i].nom);
		toupper(tmp_nom2);
		if (strcmp(tmp_nom, tmp_nom2) == 0)//Compare lexicalement
		{
			return i;//On compare les chaines et on renvoie la position de celles qui sont identiques
		}
}
	
#else
#ifdef IMPL_LIST
// ajouter code ici pour Liste
	strcpy_s(tmp_nom, MAX_NOM, nom);
	toupper(tmp_nom);
	LinkedList* tmp = rep->liste;//La variable tmp, temporaire va �tre utilis� uniquement dans cette fonction le temps de la recherche du contact.
	for (int i = 0; i < rep->nb_elts; i++)
	{
		strcpy_s(tmp_nom2, MAX_NOM, tmp->head->pers.nom);
		toupper(tmp_nom2);
		if (strcmp(tmp_nom, tmp_nom2) == 0)//On compare avec le nom recherch�
		{
			return i;//On retourne la position du nom qui correspond ou pas.
		}
		tmp = tmp->head->next; //On passe au nom suivant
	}
	
#endif
#endif

	return((trouve) ? i : -1);
} /* fin rechercher_nom */

  /*********************************************************************/
  /* Supprimer tous les caracteres non num�riques de la chaines        */
  /*********************************************************************/
void compact(char *s)
{
	// compl�ter code ici
	for (int i = 0; i < strlen(s); i++)//Test sur l'int�gralit� de la cha�ne
	{
		if (!isdigit(s[i]))//IsDigit permet de tester si un caract�re est un chiffre d�cimal ou non. Si elle renvoie "false", le caract�re trouv� n'est pas num�rique.
		{
			for (int j = i; j < strlen(s); j++)//Cette boucle permet de supprimer le caract�re non num�rique de la cha�ne.
				s[j] = s[j + 1];
			i--;
		}
	}
}

/**********************************************************************/
/* sauvegarde le r�pertoire dans le fichier dont le nom est pass� en  */
/* argument                                                           */
/* retourne OK si la sauvegarde a fonctionn� ou ERROR sinon           */
/**********************************************************************/
int sauvegarder(Repertoire *rep, char nom_fichier[])
{
	FILE *fic_rep; /* le fichier */
#ifdef IMPL_TAB
	// ajouter code ici pour tableau
	trier(rep);//Le r�pertoir a besoin d'�tre trier avant toute action de "sauvegarde"
	char* tmp = malloc(sizeof(char) * sizeof(Enregistrement));//On alloue l'espace dynamiquement
	int openSuccess = fopen_s(&fic_rep, nom_fichier, "w");//Fonction incluse dans <stdio.h>, avec la lettre "w", on l'ouvre en �criture. Si le fichier existe d�j�, il sera remplac�.
	if (!openSuccess)//Si une valeur NON NULLE est retourn�e, cela signifie que le fichier s'est correctement ouvert.
		for (int i = 0; i < rep->nb_elts; i++)//utilisation d'une boucle pour pouvoir factoriser le code.
		{
			sprintf_s(tmp, MAX_NOM + MAX_NOM + MAX_TEL, "%s%c%s%c%s%c\n", rep->tab[i].nom, SEPARATEUR, rep->tab[i].prenom, SEPARATEUR, rep->tab[i].tel, SEPARATEUR);//Fonction pour �crire dans le fichier
			fputs(tmp, fic_rep);//Fonction inclue dans <stdio.h>, elle permet d'�crire une chaine de caract�re sur un flux de donn�e. En gros: elle cr�e de l'espace.
		}
	fclose(fic_rep);//Fonction qui ferme le fichier
#else
#ifdef IMPL_LIST
	// ajouter code ici pour Liste
	//La m�thode est identique � celle du tableau. Mis � part la d�finition des variables au d�but.
	trier(rep);
	char* tmp = malloc(sizeof(char) * sizeof(Enregistrement));
	LinkedList* list = rep->liste;//On a besoin de cette variable "en plus" pour acc�der aux diff�rents contacts.
	int openSucces = fopen_s(&fic_rep, nom_fichier, "w");
	if (!openSucces)
		for (int i = 0; i < rep->nb_elts; i++)
		{
			sprintf_s(tmp, MAX_NOM + MAX_NOM + MAX_TEL, "%s%c%s%c%s%c\n", list->head->pers.nom, SEPARATEUR, list->head->pers.prenom, SEPARATEUR, list->head->pers.tel, SEPARATEUR);
			fputs(tmp, fic_rep);
			list = list->head->next;
		}
	fclose(fic_rep);
#endif
#endif

	return(OK);
} /* fin sauvegarder */


  /**********************************************************************/
  /*   charge dans le r�pertoire le contenu du fichier dont le nom est  */
  /*   pass� en argument                                                */
  /*   retourne OK si le chargement a fonctionn� et ERROR sinon         */
  /**********************************************************************/

int charger(Repertoire *rep, char nom_fichier[])
{
	FILE *fic_rep;					/* le fichier */
	errno_t err;
	int num_rec = 0;						/* index sur enregistrements */
	int long_max_rec = sizeof(Enregistrement);
	char buffer[sizeof(Enregistrement) + 1];
	int idx = 0;

	char *char_nw_line;
	
	_set_errno(0);
	if ( ((err = fopen_s(&fic_rep, nom_fichier, "r")) != 0) || (fic_rep == NULL) )
	{
		return(err);
	}
	else
	{
		while (!feof(fic_rep) && (rep->nb_elts < MAX_ENREG))
		{
			if (fgets(buffer, long_max_rec, fic_rep) != NULL)
			{
				/* memorisation de l'enregistrement lu dans le tableau */
				buffer[long_max_rec] = 0;			/* en principe il y a deja un fin_de_chaine, cf fgets */

				if ((char_nw_line = strchr(buffer, '\n')) != NULL)
					*char_nw_line = '\0';			/* suppression du fin_de_ligne eventuel */

				idx = 0;								/* analyse depuis le debut de la ligne */
#ifdef IMPL_TAB
				if (lire_champ_suivant(buffer, &idx, rep->tab[num_rec].nom, MAX_NOM, SEPARATEUR) == OK)
				{
					idx++;							/* on saute le separateur */
					if (lire_champ_suivant(buffer, &idx, rep->tab[num_rec].prenom, MAX_NOM, SEPARATEUR) == OK)
					{
						idx++;
						if (lire_champ_suivant(buffer, &idx, rep->tab[num_rec].tel, MAX_TEL, SEPARATEUR) == OK)
							num_rec++;		/* element � priori correct, on le comptabilise */
					}
				}
#else
#ifdef IMPL_LIST
			// ajouter code implemention liste

				//J'ai utilis� la m�me m�thode que le tableau mais adapt� � une liste.
				LinkedList* list = rep->liste;
				if (lire_champ_suivant(buffer, &idx, list->head->pers.nom, MAX_NOM, SEPARATEUR) == OK)
				{
					idx++;							/* on saute le separateur */
					if (lire_champ_suivant(buffer, &idx, list->head->pers.prenom, MAX_NOM, SEPARATEUR) == OK)
					{
						idx++;
						if (lire_champ_suivant(buffer, &idx, list->head->pers.tel, MAX_TEL, SEPARATEUR) == OK)
							num_rec++;		/* element � priori correct, on le comptabilise */
					}

				}
				list->head->next = malloc(sizeof(LinkedList));
				list = list->head->next;
#endif
#endif




			}

		}
		rep->nb_elts = num_rec;
		fclose(fic_rep);
		return(OK);
	}


} /* fin charger */