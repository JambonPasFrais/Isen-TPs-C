#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>
#include "ConsoleTools.h"
#include <string.h>

int main(int argc, char* argv[])
{
	OpenConsole();
	setlocale(LC_ALL, "fr-FR");
	int i = 0, choix = 0, Max = 0, Min = 0, partie = 1;
	printf("Hello !\n");
	d�but : printf("Souhaites-tu jouer en solo ou � deux ? S/D\n");
	char car = readChar("SsDd");
	if (car == 's' || car == 'S') {
		printf("En solo ? Parfait, quel est votre niveau ?\n1: Amateur\n2: Interm�diaire\n3: Pro\n4: ULTIME\n");
		char choix;
	lvlselector: choix = readChar("1234");
		switch (choix)
		{
		case'1': printf("En avant pour le niveau Amateur !\n ");
			printf("===================================\n |**G�n�ration du Nombre en Cours**|\n |**       Entre 1 et 100        **|\n ===================================\n");
			int nombreMystere = 0, nombreEntre = 0;
			Max=100 , Min = 1;
			srand(time(NULL));
			nombreMystere = (rand() % (Max - Min + 1)) + Min;

			do
			{
				printf("Quel est le nombre ? ");
				scanf_s("%d", &nombreEntre);

				if (nombreMystere > nombreEntre) {
					printf("C'est plus !\n\n");
					i = i + 1;
				}
				else if (nombreMystere < nombreEntre) {
					printf("C'est moins !\n\n");
					i = i + 1;
				}
				else {
					printf("Bravo, tu as trouv� le nombre mystere !!!\n");
					printf("En %d essaies\nBravo!!\n", i);
				}
			} while (nombreEntre != nombreMystere);

			printf("Tu veux rejouer ? O/N\n");
			char cari = readChar("OnoN");
			if (cari == 'O' || cari == 'o') {
				printf("C'est reparti !\n");
				system("pause");
				system("cls");
				goto d�but;
			}
			else {
				printf("Ok, A bient�t !\n");
				return(EXIT_SUCCESS);
				CloseConsole();
			}

			return 0;
			break;
		case'2': printf("En avant pour le niveau Interm�diire !\n");
			printf(" ===================================\n |**G�n�ration du Nombre en Cours**|\n |**       Entre 1 et 1000       **|\n ===================================\n");
			nombreMystere = 0, nombreEntre = 0;
			Max = 1000, Min = 1;
			srand(time(NULL));
			nombreMystere = (rand() % (Max - Min + 1)) + Min;

			do
			{
				printf("Quel est le nombre ? ");
				scanf_s("%d", &nombreEntre);

				if (nombreMystere > nombreEntre) {
					printf("C'est plus !\n\n");
					i = i + 1;
				}
				else if (nombreMystere < nombreEntre) {
					printf("C'est moins !\n\n");
					i = i + 1;
				}
				else {
					printf("Bravo, tu as trouv� le nombre mystere !!!\n");
					printf("En %d essaies\nBravo!!\n", i);
				}
			} while (nombreEntre != nombreMystere);

			printf("Tu veux rejouer ? O/N\n");
			char carii = readChar("OnoN");
			if (carii == 'O' || carii == 'o') {
				printf("C'est reparti !\n");
				system("pause");
				system("cls");
				goto d�but;
			}
			else {
				printf("Ok, A bient�t !\n");
				return(EXIT_SUCCESS);
				CloseConsole();
			}

			return 0;
			break;
		case'3': printf("En avant pour le niveau Pro !\n");
			printf(" ===================================\n |**G�n�ration du Nombre en Cours**|\n |**      Entre 1 et 10000       **|\n ===================================\n");
			nombreMystere = 0, nombreEntre = 0;
			Max = 10000, Min = 1;
			srand(time(NULL));
			nombreMystere = (rand() % (Max - Min + 1)) + Min;

			do
			{
				printf("Quel est le nombre ? ");
				scanf_s("%d", &nombreEntre);

				if (nombreMystere > nombreEntre) {
					printf("C'est plus !\n\n");
					i = i + 1;
				}
				else if (nombreMystere < nombreEntre) {
					printf("C'est moins !\n\n");
					i = i + 1;
				}
				else {
					printf("Bravo, tu as trouv� le nombre mystere !!!\n");
					printf("En %d essaies\nBravo!!\n", i);
				}
			} while (nombreEntre != nombreMystere);

			printf("Tu veux rejouer ? O/N\n");
			char cariii = readChar("OnoN");
			if (cariii == 'O' || cariii == 'o') {
				printf("C'est reparti !\n");
				system("pause");
				system("cls");
				goto d�but;
			}
			else {
				printf("Ok, A bient�t !\n");
				return(EXIT_SUCCESS);
				CloseConsole();
			}

			return 0;
			break;
		case'4': printf("En avant pour le niveau ULTIME\n");
			printf(" ===================================\n |**G�n�ration du Nombre en Cours**|\n ===================================\n");
			nombreMystere = 0, nombreEntre = 0;

			srand(time(NULL));
			nombreMystere = (rand());

			do
			{
				printf("Quel est le nombre ? ");
				scanf_s("%d", &nombreEntre);

				if (nombreMystere > nombreEntre) {
					printf("C'est plus !\n\n");
					i = i + 1;
				}
				else if (nombreMystere < nombreEntre) {
					printf("C'est moins !\n\n");
					i = i + 1;
				}
				else {
					printf("Bravo, tu as trouv� le nombre mystere !!!\n");
					printf("En %d essaies\nBravo!!\n", i);
				}
			} while (nombreEntre != nombreMystere);

			printf("Tu veux rejouer ? O/N\n");
			char cariiii = readChar("OnoN");
			if (cariiii == 'O' || cariiii == 'o') {
				printf("C'est reparti !\n");
				system("pause");
				system("cls");
				goto d�but;
			}
			else {
				printf("Ok, A bient�t !\n");
				return(EXIT_SUCCESS);
				CloseConsole();
			}

			return 0;
			break;
		default:printf("Choisissez un nombre entre 1 et 4 on a dit !\n"); goto lvlselector;
			break;
		}
	}


	//Jeu � Deux !
	else if (car == 'd' || car == 'D') {
		printf("A deux ?\nQue le premier joueur entre son pseudo: ");
		char Pseudo1[100];
		char Pseudo2[100];
		scanf_s("%s", Pseudo1);
		printf("\nBonjour %s\nQue le deuxi�me joueur entre son pseudo: ", *Pseudo1);
		scanf_s("%s", Pseudo2);
		printf("\nBonjour %s\nCommen�ons !\n", Pseudo2);
		system("pause");
		system("cls");
		//Premier Tour
		unsigned long NombreMystere;
		printf("%s : Tu dois faire deviner un nombre, entre-le ci-dessous:\n", Pseudo1);
		scanf_s("%d", &NombreMystere);
		printf("Ok ! Appuye sur une touche et passe l'ordinateur au %s !\n", Pseudo2);
		system("pause");
		system("cls");
		unsigned long NombreEntre;

		do
		{
			printf("%s: Quel est le nombre ? ", Pseudo2);
			scanf_s("%d", &NombreEntre);


			if (NombreMystere > NombreEntre) {
				printf("C'est plus !\n\n");
				i = i + 1;
			}
			else if (NombreMystere < NombreEntre) {
				printf("C'est moins !\n\n");
				i = i + 1;
			}
			else {
				printf("Bravo, tu as trouv� le nombre myst�re !!!\n");
				printf("Score = %d", i);
			}	
		} while (NombreEntre != NombreMystere);

		//2 �me tour
		printf("\n\n%s : A ton tour ! Tu dois faire deviner un nombre, entre-le ci-dessous:\n", Pseudo2);
		scanf_s("%d", &NombreMystere);
		printf("Ok ! Appuye sur une touche et passe l'ordinateur � %s !\n", Pseudo1);
		system("pause");
		system("cls");
		int i2 = 0;

		do
		{
			printf("%s : Quel est le nombre ? ", Pseudo1);
			scanf_s("%d", &NombreEntre);


			if (NombreMystere > NombreEntre) {
				printf("C'est plus !\n\n");
				i2 = i2 + 1;
			}
			else if (NombreMystere < NombreEntre) {
				printf("C'est moins !\n\n");
				i2 = i2 + 1;
			}
			else {
				printf("Bravo, tu as trouv� le nombre myst�re !!!\n");
				printf("Score = %d", i2);
			}
		} while (NombreEntre != NombreMystere);
		if (i2 > i) {
			printf("\nBravo %s, c'est gagn� !!!!!\n", Pseudo2);
		}
		else if (i2 < i) {
			printf("\nBravo %s, c'est gagn� !!!!\n", Pseudo1);
		}
		else {
			printf("\nVous �tes � �galit�, GG !\n");
		}

		printf("On rejoue ? O/N\n");
		char cari = readChar("OnoN");
		if (cari == 'O' || cari == 'o') {
			printf("C'est reparti !\n");
			system("pause");
			system("cls");
			goto d�but;
		}
		else {
			printf("Ok, A bient�t !\n");
			return(EXIT_SUCCESS);
			CloseConsole();
		}
	}
}