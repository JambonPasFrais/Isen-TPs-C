#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL, "fr-Fr");
	//Avec for
	int i1;
	int n;
	unsigned short int somme1 = 0;

	printf("Merci d'entrer la valeur de n, telle que n soit sup�rieur � 1:");
	scanf_s("%d", &n);
	if (n > 361) {
		printf("\nDesol� n est trop grand, veuillez recommencer:\n");
		return main();
	}
	else
	{
		for (i1 = 0; i1 < n + 1; i1++) {
			somme1 = i1 + somme1;
		}
		printf("\nVoici la valeur de n : %d", n);
		printf("\nVoici la valeur de la somme : %d", somme1);
	}
	
	// Avec While n=361 MAX
	int i2 = 0; 
	unsigned short int somme2 = 0;
	printf("\n\nMerci d'entrer la valeur de n, telle que n soit sup�rieur � 1:");
	scanf_s("%d", &n);//Avec cette fonction %hu : la somme devient n�gative ! Ce qui est impossible
	while ( i2 < n) {
		i2 = i2 + 1;
		somme2 = i2 + somme2;
		if (n>361){
			printf("\nN est trop grand, le r�sultat affich� ne sera pas le bon, merci de recommencer.\n");
			return main();
		}
	}
	printf("\nVoici la valeur de n : %d", n);
	printf("\nVoici la valeur de la somme : %d", somme2);

	//Avec do While
	int i3 = 0;
	unsigned short int somme3 = 0;
	printf("\n\nMerci d'entrer la valeur de n telle que n soit sup�rieur � 1:");
	scanf_s("%d", &n);
	if (n > 361) {
		do {
			i3 = i3 + 1;
			somme3 = somme3 + i3;
		} while (i3 < n);
		printf("\nVoici la valeur de n : %d", n);
		printf("\nVoici la valeur de la somme:%d", somme3);
	}
	else {
		printf("D�sol�, �a marche pas! Recommence !");
		return main();
	}
}