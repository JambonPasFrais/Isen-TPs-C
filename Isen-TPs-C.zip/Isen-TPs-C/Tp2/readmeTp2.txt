Nom :Deffrennes
Pr�nom :Armand
classe :CIR 1

Placez vos fichiers sources (.c , .h ) dans le fichier Nom.Pr�nom.zip (mettez les v�tres) 
et d�posez ce fichier sur le "devoir" TPx sur la team office365.

Commentaires : Voici le TP d'algo n�2.
