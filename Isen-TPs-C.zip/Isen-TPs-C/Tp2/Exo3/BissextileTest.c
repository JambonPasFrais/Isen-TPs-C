#include <stdio.h>
#include <locale.h>
#include<stdlib.h>
#include <math.h>

int main() {
	setlocale(LC_ALL, "fr-FR");
	int Annee;
	printf("Merci d'entrer une ann�e entre l'an 0 et l'ann�e 10000 pour savoir si elle est bissextile ou non:\nAnn�e: ");
	scanf_s("%d", &Annee);

	if (Annee % 4 == 0 && Annee % 100 != 0 || Annee % 400 == 0) {
		printf("\nL'ann�e %d est bissextile", Annee);
	}
	else {
		printf("\nL'ann�e %d n'est pas bissextile", Annee);
	}
	return 0;
}