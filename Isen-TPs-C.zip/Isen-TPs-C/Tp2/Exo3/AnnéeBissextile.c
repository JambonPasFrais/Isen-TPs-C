#include <stdio.h>
#include <locale.h>
#include<stdlib.h>
#include <math.h>

int main() {
	setlocale(LC_ALL, "fr-FR");
	int Ann�e;
	printf("Merci d'entrer une ann�e entre l'an 0 et l'ann�e 10000 pour savoir si elle est bissextile ou non:\nAnn�e: ");
	scanf_s("%d", &Ann�e);
	if (0 <= Ann�e || Ann�e <= 10000) {
		if (Ann�e<=0 || Ann�e>=10000) {
			printf("On a dit entre 0 et 10000 patate !\nRecommence:\n");
			return main();
		}
		else {
			if (Ann�e % 100 == 0) {
				if (Ann�e % 400 == 0) {
					printf("L'ann�e %d est bissextile\n", Ann�e);
				}
				else {
					printf("L'ann�e %d n'est pas bissextile\n", Ann�e);
				}
			}
			else {
				if (Ann�e % 4 == 0) {
					printf("%d est une ann�e bissextile!\n", Ann�e);
				}
				else {
					printf("\%d n'est pas une ann�e bissextile\n", Ann�e);
				}
			}
		}
	}
	system("pause");
	system("cls");
	printf("Recommen�ons: \n");
	return main();
}