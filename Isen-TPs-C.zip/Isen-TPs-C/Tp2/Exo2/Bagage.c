#include <stdio.h>
#include <stdlib.h>	
#include <locale.h>
#include <math.h>
#include "ConsoleTools.h"

int main() {
	setlocale(LC_ALL, "fr-FR");
	OpenConsole();
	float Longueur;
	float Largeur;
	float Hauteur;
	printf("|Testeur de Bagage|\nVeuillez entrez les dimensions de ceux-ci:\n");
	printf("Longueur:");
	scanf_s("%f", &Longueur);
	printf("Largeur:");
	scanf_s("%f", &Largeur);
	printf("Hauteur:");
	scanf_s("%f", &Hauteur);
	if (Longueur > 55||Longueur<=0) {
		printf("\nD�sol� votre bagage est trop long et ne peut �tre admis dans l'avion... \nVeuillez recommencer.\n\n");
		system("pause");
		system("cls");
		return main();
	}
	else {
		printf("\nVotre bagage a la bonne longueur\n !");
		system("pause");
	}
	if (Largeur > 25||Largeur<=0) {
		printf("Par contre, votre bagage est trop large et ne peut �tre admis dans l'avion... \nVeuillez recommencer.\n\n");
		system("pause");
		system("cls");
		return main();
	}
	else {
		printf("Il a �galement la largeur ad�quate!\n");
		system("pause");
	}
	if (Hauteur > 35|| Hauteur <=0) {
		printf("Mais votre bagage est trop haut et ne peut �tre admis dans l'avion... \nVeuillez recommencer.\n\n");
		system("pause");
		system("cls");
		return main();
	}
	else {
		printf("Votre bagage a �galement la hauteur id�ale!\n");
		system("pause");
	}
	if (0<Largeur <= 25 || 0<Hauteur <= 35 || 0<Longueur <= 55) {
		printf("\nF�licitation ! Votre bagage est admis dans l'avion.");
	}
	printf("\n\nSouhaitez-vous tester une autre valise ? O/N");
	char car = readChar("OoNn");

	while (car == 'o' || car == 'O') {
		printf("\nOk ! C'est reparti !\n");
		system("pause");
		system("cls");
		return main();
	}
	if (car == 'N' || car == 'n') {
		printf("\nTr�s bien, a bient�t !");
	}
	CloseConsole();
}