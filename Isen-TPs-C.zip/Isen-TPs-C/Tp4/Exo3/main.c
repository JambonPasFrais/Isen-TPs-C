#include <locale.h>
#include <stdio.h>
#include <stdlib.h>


int main() {
	setlocale(LC_ALL,"fr-Fr");
	char nom[20], pr�nom[20], sexe;
	printf("Bonjour, quel est ton pr�nom ?\n");
	scanf_s("%s", pr�nom, (unsigned)_countof(pr�nom));
	printf("Ton nom ?\n");
	scanf_s("%s", nom, (unsigned)_countof(nom));
	printf("\nQuel est on sexe ? H/F\n");
	sexe = _getch();
	switch (sexe)
	{
	case 'h':
	case 'H': printf("Monsieur %s %s", pr�nom, nom);
		break;
	case 'F':
	case 'f': printf("Madame %s %s", pr�nom, nom);
		break;
	}
}