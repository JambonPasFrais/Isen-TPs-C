#define _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <string.h>

int main() {
	setlocale(LC_ALL, "fr-Fr");
	printf("Veuillez entrer une phrase (sans accents) :\n");
	char buffer[1024]; int NombreDeMot = 1; char car = ' ', cari = '\'', carii = '-';
	gets_s(buffer, 1024);
	int size = strlen (buffer);
	printf("Vous avez entrez la phrase: \"%s\"", buffer);
	for (int i = 0; i < size; i++) {
		if (buffer[i] == car || buffer[i] == cari || buffer[i] == carii) {
			NombreDeMot++;
			size--;
		}
	}
	printf("\nVous avez %d mots dans votre cha�ne", NombreDeMot);
	double MoyenneCar = (float) size / NombreDeMot;
	printf("\nVous avez en moyenne %.2f caract�res/mots", MoyenneCar);
}