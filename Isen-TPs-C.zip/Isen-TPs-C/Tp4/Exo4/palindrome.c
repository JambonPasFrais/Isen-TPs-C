#define _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <stdio.h>

int main() {
	setlocale(LC_ALL, "fr-Fr");
	char mot[30], test[30];
	printf("Saisis ton mot !\n");
	scanf_s("%s", mot, (unsigned)_countof(mot));
	int SizeMot = 0, Ok = 0;
	SizeMot = strlen(mot);
	if (SizeMot % 2 == 0 || SizeMot <= 1) {
		printf("Ce mot n'est pas un palindrome.");
	}
	else {
		strcpy(test, mot);
		_strrev(mot);
		printf("A l'enver cela donne: %s\n", mot);
		for (int i = 0; i < SizeMot; i++) {
			if (test[i] == mot[i]) {
				Ok++;
			}
			else {
				Ok--;
				printf("La lettre %d ne correspond pas\n", i + 1);
			}
		}
		if (Ok != SizeMot) {
			printf("Ce n'est pas un palindrome");
		}
		else if (Ok == SizeMot) {
			printf("C'est un palindrome");
		}
	}
}