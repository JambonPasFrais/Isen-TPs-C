#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL, "fr-Fr");
	srand(time(NULL));
	int Tab[100] = { 0 }; int Recherche = 0; int* Curseur = &(*Tab); int i = 0; int found = 0;
	for (i = 0; i < 100; i++) {
		Tab[i] = rand() % 21;
		printf("Case %d: %d; ", i + 1, Tab[i]);//J'ai affich� le tableau pour avoir un �l�ment de correction.
	}
	printf("\nQuel nombre veux-tu chercher dans le tableau ?\n");
	scanf_s("%d", &Recherche);
	for (*Curseur = &(*Tab); *Curseur < (*Tab + 100); Curseur++) {
		i++;
		if (Recherche == *Curseur) {
			printf("\nLe Nombre %d trouv� en case %d", Recherche, i-100);
			found++;
		}
	}
	if (found == 0) {
		printf("Le nombre %d n'a pas �t� trouv� dans le tableau", Recherche);
	}
}