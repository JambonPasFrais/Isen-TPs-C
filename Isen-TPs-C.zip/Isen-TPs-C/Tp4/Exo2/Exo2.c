#include<stdio.h>

#define SEPARATEUR '/'
#define TAILLETAB1 20

int main() {
	int MyTab1[TAILLETAB1];
	for (int i = 0; i < TAILLETAB1; i++) {
		MyTab1[i] = i+1;
		printf("%d%c",MyTab1[i], SEPARATEUR);
	}
	printf("\nChangement de partie\n");
	int* MyPtr1;
	MyPtr1 = &MyTab1[19];
	for (int i = 0; i < TAILLETAB1; i++) {
		printf("%d%c", *MyPtr1, SEPARATEUR);
		MyPtr1--;
	}
}