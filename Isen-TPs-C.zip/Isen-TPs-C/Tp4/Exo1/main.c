#include <stdio.h>
#include <locale.h>
#include "tp4.h"

int main() {
	setlocale(LC_ALL, "fr-Fr");
	HEURE D�but, Fin, Dur�e;
	D�but.heure = 12; D�but.minute = 30;
	Dur�e.heure = 3; Dur�e.minute = 45;
	Fin.heure = D�but.heure + Dur�e.heure;
	Fin.minute = D�but.minute + Dur�e.minute;
	while (Fin.minute >= 60) {
		Fin.minute = Fin.minute % 60;
		Fin.heure++;
	}
	printf("Heure de d�but: %d:%d\n", D�but.heure, D�but.minute);
	printf("Dur�e: %d:%d\n", Dur�e.heure, Dur�e.minute);
	printf("Heure de fin: %d:%d\n", Fin.heure, Fin.minute);
}