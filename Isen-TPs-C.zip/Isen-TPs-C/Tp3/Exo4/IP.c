#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <locale.h>

int main() {
	setlocale(LC_ALL, "fr-Fr");
	unsigned int MyAddress_w = 192, MyAddress_x = 168, MyAddress_y = 129, MyAddress_z = 10;//On d�finit toutes les adresses n�c�ssaires.
	unsigned int WRES = 0, XRES = 0, YRES = 0, ZRES = 0;
	unsigned int broadw = 0, broadx = 0, broady = 0, broadz = 0;
	unsigned int IPV4MaskLength = 24;

	long long MASKNUMBER = pow(2.0, 32.0) - pow(2.0, (32.0 - IPV4MaskLength)); //On passe le MASK en nombre entier pour effectuer les caluls.

	WRES = MyAddress_w & (MASKNUMBER >> 24);//On chercher l'adresse r�seaux avec le MASK en nombre entier et l'adresse IPV4.
	XRES = MyAddress_x & (MASKNUMBER >> 16);
	YRES = MyAddress_y & (MASKNUMBER >> 8);
	ZRES = MyAddress_z & MASKNUMBER;

	broadw = WRES | (~MASKNUMBER) >> 24;//On cherche l'adresse Broadcast avec le MASK ennombre entier et l'adresse RESEAUX.
	broadx = XRES | (~MASKNUMBER) >> 16;
	broady = YRES | (~MASKNUMBER) >> 8;
	broadz = ZRES | (~MASKNUMBER);

	printf("Adresse         IPv4 = %d.%d.%d.%d / %d \n", MyAddress_w, MyAddress_x, MyAddress_y, MyAddress_z, IPV4MaskLength);//On envoie les r�sultats comme demand�s.
	printf("Adresse du r�seau = %d.%d.%d.%d / %d \n", WRES, XRES, YRES, ZRES, IPV4MaskLength);
	printf("Adresse broadcast = %d.%d.%d.%d", broadw & 0xFF, broadx & 0xFF, broady & 0xFF, broadz & 0xFF);

	return 0;
}