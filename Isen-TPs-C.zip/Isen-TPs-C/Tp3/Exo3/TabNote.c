#include <stdio.h>
#include <math.h>
#include "ConsoleTools.h"
#define NBMAXNOTES 30


int main() {
	int noteValides = 0, nbAbsent = 0;
	float note[NBMAXNOTES], noteMax = 0, noteMin = 20;
	note[0] = -2;
	for (int i = 0; i < NBMAXNOTES; i++) {
		float currentNote;
	scan:printf("entrez la note %d: ", i + 1);
		scanf_s("%f", &currentNote); 
		if (currentNote <= 20 && currentNote >= 0) {
			note[i] = currentNote;
		}
		else {
			printf("\nEleve absent ? ou voulez-vous arr�ter la saisie des notes ? A/O/N\n");
			char choix = _getch();
			if (choix == 'O' || choix == 'o') {
				i == NBMAXNOTES;
				break;
			}
			else if (choix == 'a' || choix == 'A') {
				note[i] = -1;
			}
			else {
				goto scan;
			}
		}
	}	
	for (int i = 0; i < NBMAXNOTES; i++) {
		if (note[i] == -1) nbAbsent++;
		if (note[i] < noteMin && note[i] > 0 && note[i] <= 20) noteMin = note[i];
		if (note[i] > noteMax&& note[i] > 0 && note[i] <= 20) noteMax = note[i];
		if (note[i] <= 20 && note[i] >= 0) noteValides++;
	}
	float moyenne = 0;
	for (int i = 0; i < NBMAXNOTES; i++) {
		if (note[i] >= 0 && note[i] <= 20)moyenne += note[i];
	}
	moyenne /= noteValides;
	long float ecart_type = 0;
	for (int i = 0; i < NBMAXNOTES; i++) {
		if (note[i] <= 20 && note[i] >= 0) ecart_type += pow(note[i] - moyenne, 2);
	}
	ecart_type /= NBMAXNOTES - 1;
	ecart_type = sqrt(ecart_type);
	printf("\nil y a %d absents, %d notes valides; la note max est %.2f et la note min est %.2f", nbAbsent, noteValides, noteMax, noteMin);
	printf("\nla moyenne est de %.2f, et l\'ecart type est de %.2lf\n", moyenne, ecart_type);
	printf("l'ensemble des notes entres est: ");
	for (int i = 0; i < NBMAXNOTES; i++) {
		printf("\nnote %d: %.2f", (i + 1), note[i]);
	}
	return 0;
}