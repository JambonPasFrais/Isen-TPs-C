#define carre(x) (x)*(x)
#include <stdio.h>

	
int main() {
	int Nb = 5;
	int a = carre(Nb); // Carr� de 5 = 25
	printf("%d", a);// a = 25
	a = carre(Nb + 1);// Carr� de 6 = 36
	printf("\n%d", a);//a = 11 (?) !
	//Probl�me ? Comment counter ce Probl�me ?
	//Pour r�gler ce probl�me, il suffit de mettre des parenth�ses autour des "x". Ainsi l'addition de x+1 s'effectuera avant la multiplication !
}