#include <stdio.h>

int main() {
	int nb = 2868838400;
	printf("le nombre vaut %d Octets soit %d bits\n", sizeof(nb), sizeof(nb) * 8); // Car dans 1 octet il y a 8 bits
	for (int i = 1; i <= sizeof(nb) * 8; i++) {
		if (nb & 1) {
			printf("Bit %d: ON\n", i);
		}
		else {
			printf("Bit %d: OFF\n", i);
		}
		nb = nb >> 1;
	}
	printf("Bye !!!");
	return 0;
}